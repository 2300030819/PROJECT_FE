function Register() {
    return (
      <div>
        <h1>Register</h1>
        <p>Create an account to start booking hotels.</p>
      </div>
    );
  }
  
  export default Register;
  